CREATE VIEW "Order Details Extended" AS
SELECT "Order Details".OrderID as OrderID, "Order Details".ProductID as ProductID, Products.ProductName, 
	"Order Details".UnitPrice as UnitPrice, "Order Details".Quantity as Quantity, "Order Details".Discount as Discount, 
	("Order Details".UnitPrice*Quantity*(1-Discount)/100)*100 AS ExtendedPrice
FROM Products INNER JOIN "Order Details" ON Products.ProductID = "Order Details".ProductID
--ORDER BY "Order Details".OrderID;

